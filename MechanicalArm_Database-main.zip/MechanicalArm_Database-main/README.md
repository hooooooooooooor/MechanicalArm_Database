--------------------------------------
Content:
- Seperated Controle Pages:
	- Base_Controles.html
	- Engines_Controles.html
- Combined_Controles.html
- databaseConnect.php
- Robot_Database.sql
- Robot_ERD.png
--------------------------------------
Languages Per File:
- Seperated Controle Pages:
	- Base_Controles.html (HTML ,CSS ,JS)
	- Engines_Controles.html (HTMLS, CSS)
- Combined_Controles.html (HTML, CSS, JS)
- databaseConnect.php (PHP)
- Robot_Database.sql (SQL)
- Robot_ERD.png (UML)
--------------------------------------
Content Per File:
- Seperated Controle Pages:
	- Base_Controles.html: Controles for base movment 
	- Engines_Controles.html: Controles for engines movments
- Combined_Controles.html: The main page with the base and engines controles
- databaseConnect.php: PHP file containing the database connection and controles 
- Robot_Database.sql: SQL file containing the database of name robot that has all the tables and rows needed shown in "Robot_ERD.png"
- Robot_ERD.png: Containing the diagram for the robot database
